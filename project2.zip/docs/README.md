# Project #2 - Landing Page Project

# Summary
This sample landing page demostrates the use of javascript to dynamically create a nav that contains all of the sections included in the HTML.  It also hides the nav after the user stops scrolling (after 5 seconds) and highlights the section and corresponding nav item for the section in view.  


## Demo Link
https://jimmydaleucf.github.io/FEDN-Project_2/



# Project Information

### Usage
Simply download the files and open the index.html file on your machine in any browser or visit the Preview Link above.

### Dependencies
None other than a modern web browser
